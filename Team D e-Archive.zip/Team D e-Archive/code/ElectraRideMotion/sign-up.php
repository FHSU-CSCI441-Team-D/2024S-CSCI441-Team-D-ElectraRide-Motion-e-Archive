<?php
  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood
session_start();

include 'includes/autoLoader.inc.php';


if ( isset($_SESSION['userid']) ) {
    echo 'Logging In: ' . $_SESSION['userid'] . ' ' . $_SESSION['uid'];
    echo '<br/>';
    echo '<a href="includes/logout.inc.php">LOGOUT</a>';
}

?>


<?php 
    if ( !isset($_SESSION['userid']) )
    {
?>
<section class="index-login">
    <div class="wrapper">
        <div class="index-login-signup">
            <h4>Signup:</h4>
            <form action="includes/signup.inc.php" method="POST">
                <input type="text" name="uid" placeholder="Username">
                <br/>
                <input type="password" name="pwd" placeholder="Password">
                <br/>
                <input type="password" name="pwdrepeat" placeholder="Repeat Password">
                <br/>
                <input type="text" name="email" placeholder="E-Mail">
                <br/>
                <br/>
                <button type="submit" name="submit">Sign Up</button>
            </form>
        </div>
    </div>
</section>
<?php
    }
?>
