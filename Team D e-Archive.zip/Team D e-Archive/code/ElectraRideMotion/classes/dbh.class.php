<?php
  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood
// connect to the database

    class Database {
    // it is strongly encouraged that you create environmental variables with the webserver you utilize.  
    // By publicly listing your database credentials you are at risk.
    // Please see an example below.
    // On render I added DB in front of each variable but it is only required on the PORT variable, as render has a global variable for PORT already set
    // and you cannot overwrite it.

    // private $conn;
    // private $host;
    // private $port;
    // private $dbname;
    // private $username;
    // private $password;
    
    // public function __construct() {
    //     $this->username = getenv('DBUSERNAME');
    //     $this->password = getenv('DBPASSWORD');
    //     $this->dbname = getenv('DBNAME');
    //     $this->host = getenv('DBHOST');
    //     $this->port = getenv('DBPORT');
    // }

    private $conn;
    //this is a free temporary PostgreSQL database that is only active for 3 months and will need to be updated.
    private $host = 'dpg-cnj9sued3nmc73e964c0-a.oregon-postgres.render.com'; 
    private $user = 'username'; 
    private $pwd = 'LR2en4WhdGtTlFQAOzOBXg3q8EanAyOy';
    private $dbName = 'ermdb';
    private $port = '5432';

    public function connect(){
        if($this->conn){
                return $this->conn;
        } else{
        $dsn = "pgsql:host={$this->host};port={$this->port};dbname={$this->dbName}";     // Data Source Name
        
        try {
            $this->conn = new PDO($dsn, $this->user, $this->pwd);  
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $this->conn;
        } catch ( PDOException $e ) {
            echo 'Error!: ' . $e->getMessage();
            }
            }
        }   
    }
