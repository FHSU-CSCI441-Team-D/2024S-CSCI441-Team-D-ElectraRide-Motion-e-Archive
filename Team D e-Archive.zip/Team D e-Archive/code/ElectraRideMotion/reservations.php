<?php
  // HTML written by: Daniel Sones
  // PHP written by Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood

session_start();
include 'includes/autoLoader.inc.php';
include_once "./classes/dbh.class.php";
include_once './includes/vehicle.inc.php';
include_once './includes/reservation.inc.php';


            $database = new Database;
            $db = $database->connect();
            $vehicle = new Vehicle($db);
            $reservation = new Reservation($db);
            
            if($_POST){            
            $reservation->pickup_date = $_POST['pickup'];
            $reservation->return_date = $_POST['dropoff'];
            $selectedVehicle = $_POST['car'];
            $vehicleParts = explode(",", $selectedVehicle);
            $reservation->vehicle_id = $vehicleParts[0];
            $reservation->total_price = $vehicleParts[3];
            $reservation->user_id = $_SESSION['userid'];
            
            if($reservation->create()){
              $vehicle->id = $reservation->vehicle_id;
              $vehicle->status = "Reserved";
              $vehicle->updateStatus();
              $reservation->id = $db->lastInsertId();
              
              // $to = $_SESSION['users_email'];
              // $messageSubject = "ElectraRideMotion Reservation Confirmation";
              // $body = "Please see below for your Reservation Details";


              // $body .= "Reservation Confirmation id:".$reservation->id. "\r\n";
              // $body .= "Pickup Date: ".$reservation->pickup_date. "\r\n";
              // $body .= "Return Date: ".$reservation->return_date. "\r\n";
              // $body .= "Make: ".$vehicleParts[1]. "\r\n";
              // $body .= "Model: ".$vehicleParts[2]. "\r\n";
              // $body .= "Daily Rate: ".$reservation->total_price. "\r\n";

              // mail($to,$messageSubject,$body);
            }

            }

?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
  <title>ElectaRide Motion</title>
  <script language="JavaScript" src="script/date.js"></script>
  
</head>

<body>
  <div id='wrapper'>
  <?php include('./includes/header.inc.php'); ?>
    
    <main id='ReservationMain'>
      <h1>Let's get your vehicle reserved!</h1>
      <br><br>
      <form id="reservationForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
        Date to pick up vehicle:
        <! -- Input for pickup date -->
        <input required name="pickup" type="date" id="pickup" min="<?php echo date("Y-m-d");?>" value="<?php echo date("Y-m-d");?>">
        <br><br>

        -  Date to drop off vehicle:
        <! -- Input for drop off date -->
        <input required name="dropoff" type="date" id="dropoff" min="<?php echo date("Y-m-d"); ?>" value="<?php echo date("Y-m-d");?>">
        <br><br>

        -  Select desired vehicle:
        <br><br>
        <! -- Input for vehicle -->
        <label for="car">Choose a car:</label>

        <select required name="car" id="car">
            <option value" " disabled selected>Select</option>
        <?php
            $vehicleJSON_arr = json_encode($vehicle->getVehicle());
            $vehicleJSON_arr = json_decode($vehicleJSON_arr,true);
                    for($i = 0; $i < count($vehicleJSON_arr); $i++) {
                      echo '<option value="' . $vehicleJSON_arr[$i]['id'] . ',' . $vehicleJSON_arr[$i]['make'] . ','. $vehicleJSON_arr[$i]['model'] . ',' . $vehicleJSON_arr[$i]['rental_rate'] . '">' 
                      . $vehicleJSON_arr[$i]['make'] . ' '. $vehicleJSON_arr[$i]['model'] . '</option>';
                  }
            ?>
        </select>        
        <br><br>
        <! -- Submit input into 'reservation.php' -->
        <input type="submit" value="Submit">
      </form>
      

    </main>
    
    <footer>
    </footer>
  </div>
</body>
<script language="JavaScript" src="script/reservation.js"></script>

</html>
