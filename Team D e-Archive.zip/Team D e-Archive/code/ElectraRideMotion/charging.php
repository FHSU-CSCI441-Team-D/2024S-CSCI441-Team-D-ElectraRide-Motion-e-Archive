<?php
  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood
session_start();
include 'includes/autoLoader.inc.php';
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
    <title>ElectaRide Motion</title>
    <script language="JavaScript" src="script/date.js"></script>
</head>

<body>
    <div id='wrapper'>
    <?php include('./includes/header.inc.php'); ?>
    
    <main id='ChargeMain'>

            
                <div id="afdc-stations">
                <div id="afdc-stations-loading">Loading alternative fueling station locator...</div>
                </div>
                <script
                type="text/javascript">window.afdcStationsOptions = {"country": "all", "localeCountry": "US", "path": "/find/nearest", "query": {"fuel": "ELEC"}}</script>
                <script async defer src="https://widgets.nrel.gov/afdc/station-locator/assets/embed.js"></script>
                <noscript>Please enable JavaScript to view the alternative fueling station locator.</noscript>
            

    </main>
    <footer>

    </footer>
    </div>
</body>

</html>
