<?php
  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood
session_start();

include 'includes/autoLoader.inc.php';


if ( isset($_SESSION['userid']) ) {
    echo 'Are you sure you want to Log Out ' . $_SESSION['uid'] . '?';
    echo '<br/>';
    echo '<a href="includes/logout.inc.php">LOGOUT</a>';
}

?>


<?php 
    if ( !isset($_SESSION['userid']) )
    {
?>
<section class="index-login">
    <div class="wrapper">
        <div class="index-login-login">
            <h4>Login:</h4>
            <form action="includes/login.inc.php" method="POST">
            <input type="text" name="uid" placeholder="Username">
            <br/>
            <input type="password" name="pwd" placeholder="Password">
            <br/>
            <br/>
            <button type="submit" name="submit">Login</button>
            </form>
        </div>
    </div>
</section>
<?php
    }
?>
