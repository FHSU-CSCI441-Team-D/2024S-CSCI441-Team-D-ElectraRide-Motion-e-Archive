<?php
  //written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood
session_start();
include 'includes/autoLoader.inc.php';
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
  <title>ElectaRide Motion</title>
  <script language="JavaScript" src="script/date.js"></script>
</head>

<body>
  <div id='wrapper'>
    <?php include('./includes/header.inc.php'); ?>
    
    <main id='HomeMain'>
      <div>
        <h1>Welcome to ElectraRide Motion!</h1>

      </div>
    </main>



    
    <footer>

    </footer>
  </div>
</body>

</html>
