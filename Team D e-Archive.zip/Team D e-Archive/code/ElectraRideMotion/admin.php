<?php
  // HTML written by: Paulina Habbecke
  // PHP & JS written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood

session_start();
include 'includes/autoLoader.inc.php';
include_once "./classes/dbh.class.php";
include_once './includes/vehicle.inc.php';
$database = new Database;
$db = $database->connect();
$vehicle = new Vehicle($db);
$vehicleUpdate = new Vehicle($db);

// Get list of available vehicles
$vehicles = $vehicle->getVehicle();
// Get last submitted image number
$imageHolder = $vehicle->getImage();


if(isset($_POST['hiddenADD'])){


    $vehicle->make = $_POST['make'];
    $vehicle->model =  $_POST['model'];
    $vehicle->year =  $_POST['year'];
    $vehicle->type =  $_POST['type'];
    $vehicle->status = 'Available';
    $vehicle->milage =  $_POST['mileage'];
    $vehicle->color =  $_POST['color'];
    $vehicle->image = $imageHolder['image'] + 1;;
    $vehicle->condition =  $_POST['condition'];
    $vehicle->rental_rate =  $_POST['rental_rate'];


        if($vehicle->createVehicle()){
            header("Location: admin.php");
        }
}

        if(isset($_POST['hiddenUpdate'])){
            //echo json_encode($_POST);

            $selectedVehicle = $_POST['cars'];
            $vehicleParts = explode(",", $selectedVehicle);
            $vehicle->id = $vehicleParts[0];

            $vehicle->make = $vehicleParts[1];
            $vehicle->model =  $vehicleParts[2];
            $vehicle->year =  $vehicleParts[3];
            $vehicle->type =  $vehicleParts[4];
            $vehicle->status = $vehicleParts[5];
            $vehicle->milage =  $vehicleParts[6];
            $vehicle->color =  $vehicleParts[7];
            $vehicle->image = $vehicleParts[8];;
            $vehicle->condition =  $vehicleParts[9];
            $vehicle->rental_rate =  $vehicleParts[10];


            $vehicleUpdate->id = $vehicleParts[0];
            $vehicleUpdate->make = $_POST['make'];
            $vehicleUpdate->model =  $_POST['model'];
            $vehicleUpdate->year =  $_POST['year'];
            $vehicleUpdate->type =  $_POST['type'];
            $vehicleUpdate->status = $_POST['status'];
            $vehicleUpdate->milage =  $_POST['mileage'];
            $vehicleUpdate->color =  $_POST['color'];
            $vehicleUpdate->image = $imageHolder['image'];
            $vehicleUpdate->condition =  $_POST['condition'];
            $vehicleUpdate->rental_rate =  $_POST['rental_rate'];


            if($_POST['make'] === ""){
            $vehicleUpdate->make = $vehicleParts[1];};
            if($_POST['model'] === ""){
            $vehicleUpdate->model = $vehicleParts[2];};
            if($_POST['year'] === ""){
            $vehicleUpdate->year = $vehicleParts[3];};
            if($_POST['type'] === ""){
            $vehicleUpdate->type = $vehicleParts[4];};
            if($_POST['status'] === ""){
            $vehicleUpdate->status = $vehicleParts[5];};
            if($_POST['mileage'] === ""){
            $vehicleUpdate->milage = $vehicleParts[6];};
            if($_POST['color'] === ""){
            $vehicleUpdate->color = $vehicleParts[7];};
            if($_POST['image'] === ""){
            $vehicleUpdate->image = $vehicleParts[8];};
            if($_POST['condition'] === ""){
            $vehicleUpdate->condition = $vehicleParts[9];};
            if($_POST['rental_rate'] === ""){
            $vehicleUpdate->rental_rate = $vehicleParts[10];};


            if($vehicleUpdate->update()){
                header("Location: admin.php");

            };
}



        if(isset($_POST['hiddenDelete'])){
            echo json_encode($_POST);

            $vehicle->id = $_POST['car'];
            echo json_encode($vehicle);

            if($vehicle->delete()){
                echo "Deleted";

                header("Location: admin.php");
            }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ElectraRide Motion</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <div class="container">
        <h1>Manage Inventory</h1>
        
        <!-- Add Vehicle Section -->
        <section id="addVehicle">
            <h2>Add Vehicle</h2>
            <!-- Form to add new vehicles -->
            <form id="addVehicleForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
                <!-- Input fields for vehicle details -->
                <input type="hidden" id="hiddenADD" name="hiddenADD" value="hiddenADD">
                <label for="make">Make:</label>
                <input type="text" id="make" name="make" placeholder="Enter make" required>
                <label for="model">Model:</label>
                <input type="text" id="model" name="model" placeholder="Enter model" required>
                <label for="number">Year: (YYYY)</label>
                <input type="text" id="year" name="year" placeholder="Enter year" required>
                <label for="type">Type: (Sedan, SUV, Pickup, etc...)</label>
                <input type="text" id="type" name="type" placeholder="Enter Type" required> 
                <label for="mileage">Mileage: (Max Miles on Full Charge)</label>
                <input type="number" id="mileage" name="mileage" placeholder="Enter mileage" required>
                <label for="color">Color:</label>
                <input type="text" id="color" name="color" placeholder="Enter color" required>
                <label for="condition">Condition: (New, Good, Maintenance Needed)</label>
                <input type="text" id="condition" name="condition" placeholder="Enter condition" required>
                <label for="rental_rate">Rental Rate: (000.00)</label>
                <input type="number" id="rental_rate" name="rental_rate" placeholder="1.00" step="0.01" min="0" required>


                <!--input goes to db -->

                <!-- Button to submit the form -->
                <button type="submit" onclick="confirmCreate()">Add Vehicle</button>
            </form>
        </section>

        <!-- Delete Vehicle Section -->
        <section id="deleteVehicle">
            <h2>Delete Vehicle</h2>
            <form id="deleteVehicleForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
            <input type="hidden" id="hiddenDelete" name="hiddenDelete" value="hiddenDelete">
            <!-- Search bar to find vehicle by make, model, or unique ID -->
            <input type="text" id="searchBar" placeholder="Search by type, model, or ID">
            <select name="car" id="car" onchange="showFields(this.value)">
            <!-- Default option -->
            <option value="" selected disabled>Select</option>
            <!-- Other vehicle options -->
            <?php foreach ($vehicles as $vehicle) : ?>
              <option value="<?php echo $vehicle['id']; ?>"><?php echo $vehicle['id'] . ', ' . $vehicle['make'] . ', ' . $vehicle['model']; ?></option>
            <?php endforeach; ?>
          </select>
            <!--add db of all vehicles to be able to search them-->
            <!-- Button to confirm deletion -->
            <button id="deleteButton" onclick="confirmDelete()">Delete Vehicle</button>
            </form>
        </section>

        <!-- Manage Vehicle Section -->
        <section id="manageVehicle">
            <h2>Manage Vehicle</h2>
            <!-- add form to edit existing vehicle details -->
            <form id="manageVehicleForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
                <label for="cars">Edit vehicle:</label>
                <select name="cars" id="cars" onchange="showFields(this.value)">
            <!-- Default option -->
            <option value="" selected disabled>Select</option>
            <!-- Other vehicle options -->
            <?php foreach ($vehicles as $vehicle) : ?>
              <option value="<?php echo $vehicle['id'] . ',' . $vehicle['make'] . ',' . $vehicle['model']
                . ',' . $vehicle['year'] . ',' . $vehicle['type'] . ',' . $vehicle['status'] . ',' . $vehicle['milage']
                . ',' . $vehicle['color'] . ',' . $vehicle['image'] . ',' . $vehicle['condition'] . ',' . $vehicle['rental_rate']; ?>">
                <?php echo $vehicle['id'] . ' ' . $vehicle['make'] . ' ' . $vehicle['model']; ?></option>
            <?php endforeach; ?>
          </select>
                <div id="updateVehicles" style="display: none;">
                <input type="hidden" id="hiddenUpdate" name="hiddenUpdate" value="hiddenUpdate">
                <label for="make">Make:</label>
                <input type="text" id="make" name="make" placeholder="Enter make">
                <label for="model">Model:</label>
                <input type="text" id="model" name="model" placeholder="Enter model">
                <label for="number">Year: (YYYY)</label>
                <input type="text" id="year" name="year" placeholder="Enter year">
                <label for="type">Type: (Sedan, SUV, Pickup, etc...)</label>
                <input type="text" id="type" name="type" placeholder="Enter Type"> 
                <label for="status">Status: (Availabe, Reserved, Maintenance)</label>
                <input type="text" id="status" name="status" placeholder="Enter status">
                <label for="mileage">Mileage: (Max Miles on Full Charge)</label>
                <input type="number" id="mileage" name="mileage" placeholder="Enter mileage">
                <label for="color">Color:</label>
                <input type="text" id="color" name="color" placeholder="Enter color">
                <label for="image">Image: (Image name)</label>
                <input type="text" id="image" name="image" placeholder="Enter image name">
                <label for="condition">Condition: (New, Good, Maintenance Needed)</label>
                <input type="text" id="condition" name="condition" placeholder="Enter condition">
                <label for="rental_rate">Rental Rate: (000.00)</label>
                <input type="number" id="rental_rate" name="rental_rate" placeholder="1.00" step="0.01" min="0">

            </div>

                <button type="submit" onclick="confirmModification()">Save Changes</button>
            </form>
        </section>
        <?php
        // <!-- Car in Maintenance Section -->
        // <section id="maintenance">
        //     <h2>Car in Maintenance</h2>
        //     <!-- Toggle button or dropdown menu to switch car status -->
        //     <label for="maintenanceToggle">In Maintenance:</label>
        //     <input type="checkbox" id="maintenanceToggle">
        //     <!-- Add list of cars under maintenance -->
        //     <input type="text" id="maintenanceDescription" placeholder="Cars under maintenance">
        // </section>

        // <!-- User Management Section -->
        // <section id="userManagement">
        //     <h2>User Management</h2>

        //     <!-- add list of registered users -->
        //     <table>
        //         <tr>
        //           <th>User Name</th>
        //           <th>Status</th>
        //           <th>History</th>
        //         </tr>
        //         <tr>
        //           <td></td>
        //           <td></td>
        //           <td></td>
        //         </tr>
        //         <tr>
        //           <td></td>
        //           <td></td>
        //           <td></td>
        //         </tr>
        //       </table>
        //     <button type="submit">Edit User</button>
        //     <button type="submit">Add User</button>
        //     <button type="submit">Delete User</button>
        // </section>

        // <!-- Content Management Section -->
        // <section id="contentManagement">
        //     <h2>Content Management</h2>
        //     <!-- Text editor to edit About Us page content -->
        //     <textarea id="aboutUsContent" rows="10" cols="50" placeholder="Edit About Us content"></textarea>
        //     <!-- Button to save changes -->
        //     <button id="saveAboutUs">Save Changes</button>
        // </section>

        // <!-- Reports and History Section -->
        // <section id="reportsHistory">
        //     <h2>Reports and History</h2>
        //     <!-- Display past rental history -->
        //     <!-- Include details such as renter information, rented vehicle, rental dates, total cost -->
        // </section>
        ?>
    </div>
    
    
    <script> 
    
    var carSelect = document.getElementById('cars');
    var formElement = document.getElementById("manageVehicleForm")
    
    function showFields(option) {
    var vehicleField = document.getElementById('updateVehicles');

        vehicleField.style.display = 'block';
    
    }

    function confirmCreate(event){
        var confirmMessage = `Please confirm you would like to create`;
        
        if (confirm(confirmMessage)) {
        } else {
            event.preventDefault();
        }

    }

    function confirmDelete(event){
        var confirmMessage = `Please confirm you would like to delete`;
        
        if (confirm(confirmMessage)) {
        } else {
            event.preventDefault();
        }
}
    
    function confirmModification(event){


var makeJS = formElement.elements.make.value;
var modelJS = formElement.elements.model.value;
var yearJS = formElement.elements.year.value;
var typeJS = formElement.elements.type.value;
var statusJS = formElement.elements.status.value;
var colorJS = formElement.elements.color.value;
var mileageJS = formElement.elements.mileage.value;
var imageJS = formElement.elements.image.value;
var conditionJS = formElement.elements.condition.value;
var rental_rateJS = formElement.elements.rental_rate.value;

var confirmMessage = `Please confirm your update.

                        \nMake: ${makeJS}
                        \nModel: ${modelJS}
                        \nYear: ${yearJS}
                        \nType: ${typeJS}
                        \nStatus: ${statusJS}
                        \nColor: ${colorJS}
                        \nMileage: ${mileageJS}
                        \nimage: ${imageJS}
                        \nCondition: ${conditionJS}
                        \nDaily Rate: $${rental_rateJS}`;

    if (confirm(confirmMessage)) {

      
    } else {
      event.preventDefault();

    }


    }
    
    </script>
</body>
</html>