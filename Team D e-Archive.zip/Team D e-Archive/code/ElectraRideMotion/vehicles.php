<?php
  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood
session_start();
include 'includes/autoLoader.inc.php';
include_once "./classes/dbh.class.php";
include_once './includes/vehicle.inc.php';
$database = new Database;
$db = $database->connect();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
  <title>ElectaRide Motion</title>
  <script language="JavaScript" src="script/date.js"></script>
</head>

<body>
  <div id='wrapper'>
  <?php include('./includes/header.inc.php'); ?>
    
    <main id='VehiclesMain'>
        <div class="VehicleFlex">
        <?php
            $updatedMake = filter_input(INPUT_GET, "make", FILTER_SANITIZE_ENCODED);
            
            if($updatedMake){
            $vehicle = new Vehicle($db);
            $vehicle->make = $updatedMake;
            $vehicleJSON_arr = json_encode($vehicle->getVehicle());
            $vehicleJSON_arr = json_decode($vehicleJSON_arr,true);

            }else{
            $vehicle = new Vehicle($db);
            $vehicleJSON_arr = json_encode($vehicle->getVehicle());
            $vehicleJSON_arr = json_decode($vehicleJSON_arr,true);
            }

                    for($i = 0; $i < count($vehicleJSON_arr); $i++) {

                      $make = $vehicleJSON_arr[$i]['make'];
                      $model = $vehicleJSON_arr[$i]['model'];
                      $year = $vehicleJSON_arr[$i]['year'];
                      $type = $vehicleJSON_arr[$i]['type'];
                      $status = $vehicleJSON_arr[$i]['status'];
                      $milage = $vehicleJSON_arr[$i]['milage'];
                      $rental_rate = $vehicleJSON_arr[$i]['rental_rate'];

                        echo '<div class="myBtn" data-make="' . $make . '" data-model="' . $model . '"
                        data-year="' . $year . '" data-type="' . $type . '" data-status="' . $status . '" 
                        data-milage="' . $milage . '" data-rental_rate="' . $rental_rate . '" >';
                        $filename = 'images/' . $vehicleJSON_arr[$i]['image'] . '.JPG';
                        $filename2 = 'images/' . $vehicleJSON_arr[$i]['image'] . '.jpg';
                          if (file_exists($filename)) {
                            echo '<div class="nested"><img src="images/' . $vehicleJSON_arr[$i]['image'] . '.JPG" style="width:100%"></div>';
                          } else if(file_exists($filename2)) {
                            echo '<div class="nested"><img src="images/' . $vehicleJSON_arr[$i]['image'] . '.jpg" style="width:100%"></div>';
                            } else {echo '<div class="nested"><img src="images/0.JPG" style="width:100%"></div>';
                              };
                        echo '<span class="nestedTextLeft">' . $year . ' ' . $make . ' ' . $model;
                        echo '</span>';
                        echo '<span class="nestedTextRight">Daily: $' . number_format($rental_rate, 2);
                        echo '</span>';
                        echo '</div>';
                    }
              ?>
              
        </div> 
        <div id="vehicleFilter">
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="GET">
            <label for="make">Make:</label><br>
            <select name="make">
              <option value" " disabled selected>Select</option>
            <?php
              $vehicleJSON_arr = json_encode($vehicle->getMake());
              $vehicleJSON_arr = json_decode($vehicleJSON_arr,true);
              for($i = 0; $i < count($vehicleJSON_arr); $i++) {
                echo '<option value="' . $vehicleJSON_arr[$i]['make'] . '">' 
                . $vehicleJSON_arr[$i]['make'] . '</option>';
              }
            ?>
            </select>
            <br><br>
            <input type="submit" value="Submit">
          </form>
          <br>
          <form action="./vehicles.php"><input type="submit" value="Reset"></form>
        </div>

    </main>

      <!-- The Modal -->
      <div id="myModal" class="modal">

<!-- Modal content -->
<div class="modal-content">
  <div class="modal-header">
    <span class="close">&times;</span>
    <h2>Reserve Now and Save</h2>
  </div>
  <div class="modal-body">
  
     
    <p id="modal_vehicle_info"></p> 

   <table class="vehicle-details">
  <tbody>
    <tr>
      <td class="image-cell">
      <p id="modal_content"></p>
      </td>
      <td class="text-cell">
        <ul class="vehicle-info">
          <li><span class="key">Year:</span> <span id="modal_year"></span></li>
          <li><span class="key">Make:</span> <span id="modal_make"></span></li>
          <li><span class="key">Model:</span> <span id="modal_model"></span></li>
          <li><span class="key">Type:</span> <span id="modal_type"></span></li>
          <li><span class="key">Max Milage on Full Charge:</span> <span id="modal_milage"></span></li>
          <li><span class="key">Daily Rental Rate:</span> <span id="modal_rental_rate"></span></li>
          </ul>
      </td>
    </tr>
  </tbody>
</table>

<?php 
    if ( isset($_SESSION['userid']) ) { ?>
    <form action="./reservations.php">
    <button class="modalBtn">Reserve Vehicle</button>
    </form><?php }else{
      echo "<strong>Please Log In to Reserve this Vehicle</strong>";
    } ?>
  </div>
  <div class="modal-footer">
  </div>
</div>

</div>

    
    <footer>

    </footer>
  </div>
  <script language="JavaScript" src="script/script.js"></script>
</body>

</html>
