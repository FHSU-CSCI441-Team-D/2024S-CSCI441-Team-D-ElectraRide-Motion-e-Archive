<?php
  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood

class Reservation extends Database {

private $table = 'reservation';
public $conn;

public $id;
public $user_id;
public $vehicle_id;
public $pickup_date;
public $return_date;
public $total_price;

public function __construct($db) {
    $this->conn = $db;
}


public function getReservation(){

    if(isset($this->id)){
    $sql = "SELECT * FROM reservation WHERE id = ?";

    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam('id', $this->id);
    }else if(isset($this->user_id)){
        $sql = "SELECT * FROM reservation WHERE user_id = ? ORDER BY id DESC";

        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(1, $this->user_id);
    }
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $results;
}

public function getReservation_Single(){

$current_date = date('Y-m-d');

    if(isset($this->id)){
    $sql = "SELECT * FROM reservation WHERE id = :id AND pickup_date >= :current_date ORDER BY id DESC";

    $stmt = $this->connect()->prepare($sql);
    $stmt->bindParam(':id', $this->id);
    $stmt->bindParam(':current_date', $current_date);


    }else if(isset($this->user_id)){
        $sql = "SELECT * FROM reservation WHERE user_id = :user_id AND pickup_date >= :current_date ORDER BY id DESC";

        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':current_date', $current_date);
    }
    $stmt->execute();
    $results = $stmt->fetch(PDO::FETCH_ASSOC);

    return $results;
}

public function create() {
    // Create query
    $query = "INSERT INTO $this->table (vehicle_id, user_id, pickup_date, return_date, total_price) VALUES (:vehicle_id, :user_id, :pickup_date, :return_date, :total_price)";

    // Prepare statement
    $stmt = $this->conn->prepare($query);

    // Bind data
    $stmt->bindParam(':vehicle_id', $this->vehicle_id);
    $stmt->bindParam(':user_id', $this->user_id);
    $stmt->bindParam(':pickup_date', $this->pickup_date);
    $stmt->bindParam(':return_date', $this->return_date);
    $stmt->bindParam(':total_price', $this->total_price);

    // Execute query
    if($stmt->execute()) {
    return true;
    }

// Print error if something goes wrong
    printf("Error: %s.\n", $stmt->error);
    return false;
}

public function update() {
    // Create query
      $query = "UPDATE $this->table 
                          SET vehicle_id = :vehicle_id, pickup_date = :pickup_date, return_date = :return_date, total_price = :total_price
                          WHERE id = :id";

    // Prepare statement
      $stmt = $this->conn->prepare($query);

    // Bind data
      $stmt->bindParam(':vehicle_id', $this->vehicle_id);
      $stmt->bindParam(':pickup_date', $this->pickup_date);
      $stmt->bindParam(':return_date', $this->return_date);
      $stmt->bindParam(':total_price', $this->total_price);
      $stmt->bindParam(':id', $this->id);

    // Execute query
      if($stmt->execute()) {
      return true;
      }
    // Print error if something goes wrong
    printf("Error: %s.\n", $stmt->error);
    return false;
}

public function delete() {
    // Create query
      $query = 'DELETE FROM ' . $this->table . ' WHERE id = :id';

    // Prepare statement
      $stmt = $this->conn->prepare($query);

    // Clean data
      $this->id = htmlspecialchars(strip_tags($this->id));

    // Bind data
      $stmt->bindParam(':id', $this->id);

    // Execute query
      if($stmt->execute()) {
      return true;
      }

    // Print error if something goes wrong
      printf("Error: %s.\n", $stmt->error);

      return false;
  }


    }