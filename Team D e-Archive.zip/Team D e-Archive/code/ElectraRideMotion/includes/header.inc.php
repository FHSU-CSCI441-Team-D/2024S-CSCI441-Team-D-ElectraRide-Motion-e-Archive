<?php
// written by: Sean Wood
// tested by: Sean Wood
// debugged by: Sean Wood
?>
<header>
      <table id='htbl'>
        <tr>
          <td id='jsdt'>&nbsp;&nbsp;&nbsp;
            <script language="JavaScript">
              document.write(displayDate());
            </script>
          </td>

          <td>
            <nav>
              <ul>
                <li><a href="index.php">Home &nbsp;|&nbsp;</a></li>
              <?php 
                  if ( isset($_SESSION['userid']) ) { ?>
                <li><a href="reservations.php">Reservations &nbsp;|&nbsp;</a></li> <?php } ?>
                <li><a href="vehicles.php">Vehicles &nbsp;|&nbsp;</a></li>
                <li><a href="charging.php">Charging Stations &nbsp;|&nbsp;</a></li>
                
                <li><?php 
                  if ( !isset($_SESSION['userid']) ) { ?> <a href="sign-up.php">Sign Up &nbsp;|&nbsp;</a></li>
                <li><a href="login.php">Log In &nbsp;</a></li><?php }
                  else{ echo '<div class="dropdown"><a onclick="myFunction()" class="dropbtn">' . $_SESSION['uid'] . '</a>
                    <div id="myDropdown" class="dropdown-content">
                    <a href="#home">Profile Settings</a>
                    <a href="#home">History</a>
                    <a href="modify-reservation.php">Modify Reservation</a>
                    <a href="login.php">Log Out</a>
                    </div>
                  </div></li>'; } ?>
              </ul>
            </nav>
          </td>
        </tr>
      </table>
    </header>