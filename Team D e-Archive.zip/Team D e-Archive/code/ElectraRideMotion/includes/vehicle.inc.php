<?php
  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood

class Vehicle extends Database {

public $conn;
public $table = "vehicle";
public $id;
public $make;
public $model;
public $year;
public $type;
public $status;
public $color;
public $milage;
public $image;
public $condition;
public $rental_rate;



    public function __construct($db){
        $this->conn = $db;
    }
    public function getVehicle(){
        
        // If the make is selected
        if (isset($this->make)){
            $sql = "SELECT * FROM vehicle WHERE status = 'Available' AND make = ?";
            
            $stmt = $this->connect()->prepare($sql);

            $stmt->bindParam(1, $this->make);

        }else{

        $sql = "SELECT * FROM vehicle WHERE status = 'Available' ORDER BY id";
        
        $stmt = $this->connect()->prepare($sql);
    }

        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
        }

        public function getVehicle_single(){
    
            $sql = "SELECT * FROM vehicle WHERE id = ?";
            
            $stmt = $this->connect()->prepare($sql);
            $stmt->bindParam(1, $this->id);    
            $stmt->execute();
            $results = $stmt->fetch(PDO::FETCH_ASSOC);
            return $results;
            }

    public function getMake(){
        $sql = "SELECT make FROM vehicle GROUP BY make ORDER BY make;";

        $stmt = $this->connect()->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;

    }

    public function createVehicle(){

        $query = "INSERT INTO $this->table (make, model, year, type, status, milage, color, image, condition, rental_rate) 
        VALUES (:make, :model, :year, :type, :status, :mileage, :color, :image, :condition, :rental_rate)";

    // Prepare statement
    $stmt = $this->conn->prepare($query);

    // Bind data
    $stmt->bindParam(':make', $this->make);
    $stmt->bindParam(':model', $this->model);
    $stmt->bindParam(':year', $this->year);
    $stmt->bindParam(':type', $this->type);
    $stmt->bindParam(':status', $this->status);
    $stmt->bindParam(':mileage', $this->milage);
    $stmt->bindParam(':color', $this->color);
    $stmt->bindParam(':image', $this->image);
    $stmt->bindParam(':condition', $this->condition);
    $stmt->bindParam(':rental_rate', $this->rental_rate);

    // Execute query
    if($stmt->execute()) {
    return true;
    }

// Print error if something goes wrong
    printf("Error: %s.\n", $stmt->error);
    return false;
}

public function getImage(){

        $sql = "SELECT * FROM vehicle ORDER BY image DESC";

        $stmt = $this->connect()->prepare($sql);

    $stmt->execute();
    $results = $stmt->fetch(PDO::FETCH_ASSOC);

    return $results;
}


public function update() {
    // Create query
      $query = "UPDATE $this->table 
      SET make = :make, 
      model = :model,
      year = :year,
      type = :type, 
      status = :status,
      milage = :mileage,
      color = :color,
      image = :image,
      condition = :condition,
      rental_rate = :rental_rate
      WHERE id = :id";

    // Prepare statement
      $stmt = $this->conn->prepare($query);

    // Bind data
    $stmt->bindParam(':id', $this->id);
    $stmt->bindParam(':make', $this->make);
    $stmt->bindParam(':model', $this->model);
    $stmt->bindParam(':year', $this->year);
    $stmt->bindParam(':type', $this->type);
    $stmt->bindParam(':status', $this->status);
    $stmt->bindParam(':mileage', $this->milage);
    $stmt->bindParam(':color', $this->color);
    $stmt->bindParam(':image', $this->image);
    $stmt->bindParam(':condition', $this->condition);
    $stmt->bindParam(':rental_rate', $this->rental_rate);
      

    // Execute query
      if($stmt->execute()) {
      return true;
      }
    // Print error if something goes wrong
    printf("Error: %s.\n", $stmt->error);
    return false;
}

public function updateStatus() {
  // Create query
    $query = "UPDATE $this->table 
    SET status = :status
    WHERE id = :id";

  // Prepare statement
    $stmt = $this->conn->prepare($query);

  // Bind data
  $stmt->bindParam(':id', $this->id);
  $stmt->bindParam(':status', $this->status);
  
  // Execute query
    if($stmt->execute()) {
    return true;
    }
  // Print error if something goes wrong
  printf("Error: %s.\n", $stmt->error);
  return false;
}

public function delete() {
    // Create query
      $query = "DELETE FROM  $this->table  WHERE id = :id";

    // Prepare statement
      $stmt = $this->conn->prepare($query);

    // Bind data
      $stmt->bindParam(':id', $this->id);

    // Execute query
      if($stmt->execute()) {
      return true;
      }

    // Print error if something goes wrong
      printf("Error: %s.\n", $stmt->error);

      return false;
  }

    }