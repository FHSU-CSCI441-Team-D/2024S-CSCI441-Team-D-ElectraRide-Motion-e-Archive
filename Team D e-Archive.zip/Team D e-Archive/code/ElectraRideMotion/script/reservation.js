  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood

var submitButton = document.querySelector("input[type='submit']"); // Select submit button
var carSelect = document.getElementById("car");
var formElement = document.getElementById("reservationForm")

submitButton.addEventListener("click", function(event) {
  if (carSelect.value === "" || carSelect.selectedIndex === 0) {
    event.preventDefault(); // Prevent form submission
    alert("Please select a vehicle from the dropdown list."); // Display an alert message
  }else{

var separator = ","
var carValue = formElement.elements.car.value;
// Split the value into an array
var carArray = carValue.split(separator);

var pickup_dateJS = formElement.elements.pickup.value;
var return_dateJS = formElement.elements.dropoff.value;

var makeJS = carArray[1];
var modelJS = carArray[2];
var total_priceJS = carArray[3];
console.log(pickup_dateJS);

var confirmMessage = `Please confirm your reservation.
                        \nPickup: ${pickup_dateJS}
                        \nReturn: ${return_dateJS}
                        \nMake: ${makeJS}
                        \nModel: ${modelJS}
                        \nDaily Rate: $${total_priceJS}`;

    if (confirm(confirmMessage)) {

      
    } else {
      event.preventDefault();

    }

  }
});




function confirmReservation() {

  if (confirm(confirmMessage)) {
    txt = "You pressed OK!";
  } else {
    txt = "You pressed Cancel!";
  }
  document.getElementById("demo").innerHTML = txt;
}