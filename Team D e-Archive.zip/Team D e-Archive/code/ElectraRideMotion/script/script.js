  // written by: Sean Wood
  // tested by: Sean Wood
  // debugged by: Sean Wood

// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.querySelectorAll(".myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to update modal content
function updateModalContent(year, make, model, type, status, milage, rental_rate) {
  var modalInfo = document.getElementById("modal_year");
  modalInfo.textContent = year; // Update content with year, make, and model
  var modalInfo = document.getElementById("modal_make");
  modalInfo.textContent = make;
  var modalInfo = document.getElementById("modal_model");
  modalInfo.textContent = model;
  var modalInfo = document.getElementById("modal_type");
  modalInfo.textContent = type;
  var modalInfo = document.getElementById("modal_milage");
  modalInfo.textContent = milage + "mi";
  var modalInfo = document.getElementById("modal_rental_rate");
  modalInfo.textContent = "$" + rental_rate;
  
}

// Attach click event listeners to each button
btn.forEach(function(btn) {
  btn.addEventListener("click", function() {
    // Access data attributes
    var make = this.dataset.make;
    var model = this.dataset.model;
    var year = this.dataset.year;
    var type = this.dataset.type;
    var status = this.dataset.status;
    var milage = this.dataset.milage;
    var rental_rate = this.dataset.rental_rate;

    var imageSource = this.querySelector("img").src; // Get image source from clicked button

    // Get the modal content element
    var modalContent = document.getElementById("modal_content");

    // **New: Check if an image already exists**
    var existingImage = modalContent.querySelector("img");
    if (existingImage) {
      // Remove existing image before adding a new one
      modalContent.removeChild(existingImage);
    }

    // Create a new image element for the modal
    var modalImg = document.createElement("img");
    modalImg.src = imageSource;
    modalImg.alt = make + " " + model; // Set alt text

    // Add the image to the modal content
    modalContent.appendChild(modalImg);


    modal.style.display = "block";
    updateModalContent(year, make, model, type, status, milage, rental_rate); // Call function to update modal content
  });
});


// Old function
// btn.forEach(function(btn) {
//   btn.addEventListener("click", function() {
//     modal.style.display = "block";
//   });
// });

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}