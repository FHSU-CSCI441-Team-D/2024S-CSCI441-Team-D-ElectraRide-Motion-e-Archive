<?php
  // written by: Kyle Smith
  // tested by: Kyle Smith & Sean Wood
  // debugged by: Kyle Smith & Sean Wood

session_start();
include 'includes/autoLoader.inc.php';
include "./classes/dbh.class.php";
include_once './includes/vehicle.inc.php';
include_once './includes/reservation.inc.php';

// Create instances of necessary classes
$database = new Database;
$db = $database->connect();
$vehicle = new Vehicle($db);
$myVehicle = new Vehicle($db);
$reservation = new Reservation($db);

// Get list of available vehicles
$vehicles = $vehicle->getVehicle();
$vehicleStatusA = 'Available';
$vehicleStatusR = 'Reserved';

$reservation->user_id = $_SESSION['userid'];
if ($myReservation = $reservation->getReservation_Single()){
$myVehicle->id = $myReservation['vehicle_id'];
$reserved_Vehicle = $myVehicle->getVehicle_single();}

if($_POST){

  if($_POST['modify-option'] === 'cancel-reservation'){
    // Delete the reservation
    $reservation->id = $myReservation['id'];


    if($reservation->delete()){
      $myVehicle->status = $vehicleStatusA;
      $myVehicle->updateStatus();
      header("Location: modify-reservation.php");
    }
  }else if($_POST['modify-option'] === 'change-vehicle'){

    $myVehicle->id = $_POST['cars'];
    $reserved_Vehicle2 = $myVehicle->getVehicle_single();
    $myVehicle->id = $myReservation['vehicle_id'];

    $reservation->id = $myReservation['id'];
    $reservation->vehicle_id = $_POST['cars'];
    $reservation->total_price = $reserved_Vehicle2['rental_rate'];
    $reservation->pickup_date = $myReservation['pickup_date'];
    $reservation->return_date = $myReservation['return_date'];
    // update vehicle and rate
    if($reservation->update()){
      $myVehicle->status = $vehicleStatusA;
      $myVehicle->updateStatus();
      $myVehicle->id = $_POST['cars'];
      $myVehicle->status = $vehicleStatusR;
      $myVehicle->updateStatus();
      header("Location: modify-reservation.php");
    }}else if($_POST['modify-option'] === 'change-date'){

    $reservation->id = $myReservation['id'];
    $reservation->vehicle_id = $myReservation['vehicle_id'];
    $reservation->total_price = $myReservation['total_price'];
    $reservation->pickup_date = $_POST['pickup'];
    $reservation->return_date = $_POST['dropoff'];

      //update pickup and return date
    if($reservation->update()){
      header("Location: modify-reservation.php");
    }
  
  }
}



?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
  <title>ElectaRide Motion - Modify Reservation</title>
  <script language="JavaScript" src="script/date.js"></script>
  <br>
  

  <script>
    function showFields(option) {
      var dateFields = document.getElementById('dateFields');
      var vehicleField = document.getElementById('vehicleField');

      // Hide all fields by default
      dateFields.style.display = 'none';
      vehicleField.style.display = 'none';

      // Show fields based on selected option
      if (option === 'change-date') {
        dateFields.style.display = 'block';
      } else if (option === 'change-vehicle') {
        vehicleField.style.display = 'block';
      }
    }

    function confirmModification(event) {
      var selectedOption = document.getElementById('modify-option').value;
      var selectedCar = document.getElementById('cars').value;
      var confirmationMessage = '';

      // Customize confirmation message based on selected option
      if (selectedOption === 'change-date') {
        var pickupDate = document.getElementById('pickup').value;
        var dropoffDate = document.getElementById('dropoff').value;
        confirmationMessage = 'You are changing the reservation dates. Pick up date: ' + pickupDate + ', Drop off date: ' + dropoffDate;
      } else if (selectedOption === 'change-vehicle') {
        var selectedVehicle = document.getElementById('cars').options[document.getElementById('cars').selectedIndex].text;
        confirmationMessage = 'You are changing the vehicle to: ' + selectedVehicle;
      } else if (selectedOption === 'cancel-reservation') {
        confirmationMessage = 'Are you sure you want to cancel the reservation?';
      } 
      if (selectedOption === "" || selectedOption.selectedIndex === 0){
        alert('Please choose a Modification');
        event.preventDefault()
      }
      else if (selectedCar === "" && selectedOption != 'cancel-reservation' && selectedOption != 'change-date'){
        alert('Please choose a Vehicle');
        event.preventDefault()
      }
      // Show confirmation dialog
      else if (confirm(confirmationMessage)) {
        // Submit the form
        document.getElementById('modifyForm').submit();
        // Show success message
        alert('Modification made successfully!');
        // Redirect to index page after showing the message
        //window.location.href = 'index.php';
      }
    }
  </script>
</head>

<body>
  <div id='wrapper'>
    <?php include('./includes/header.inc.php'); ?>

    <main id='ModifyReservationMain'>
      <h1>Modify Your Reservation</h1>

      
      <p><?php 
      if (isset($myReservation['id'])){
      echo "Confirmation #" . $myReservation['id'] . "<br>" .
      "Pickup Date: " . $myReservation['pickup_date'] . "<br>" .
      "Return Date: " . $myReservation['return_date'] . "<br>" .
      "Make: " . $reserved_Vehicle['make'] . "<br>" .
      "Model: " . $reserved_Vehicle['model'] . "<br>" .
      "Daily Rate: $" . $reserved_Vehicle['rental_rate'];?></p>
      <br>
      <br>
      <form id="modifyForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
        <!-- Additional options for modifying reservation -->
        <label for="modify-option">Choose modification:</label>
        <select name="modify-option" id="modify-option" onchange="showFields(this.value)">
          <option value="" selected disabled>Select</option>
          <option value="change-date">Modify Pickup/Dropoff Dates</option>
          <option value="change-vehicle">Modify Vehicle</option>
          <option value="cancel-reservation">Cancel Reservation</option>
        </select>
        <br><br>

        <!-- Fields for changing date/time -->
        <div id="dateFields" style="display: none;">
          Date to pick up vehicle:
          <input type="date" id="pickup" name="pickup" min="<?php echo date("Y-m-d"); ?>" value="<?php echo date("Y-m-d");?>">
          <br><br>
          Date to drop off vehicle:
          <input type="date" id="dropoff" name="dropoff" min="<?php echo date("Y-m-d"); ?>" value="<?php echo date("Y-m-d");?>">
          <br><br>
        </div>

        <!-- Fields for changing vehicle -->
        <div id="vehicleField" style="display: none;">
          Select desired vehicle:
          <label for="cars">Choose a car:</label>
          <select name="cars" id="cars">
            <!-- Default option -->
            <option value="" selected disabled>Select</option>
            <!-- Other vehicle options -->
            <?php foreach ($vehicles as $vehicle) : ?>
              <option value="<?php echo $vehicle['id']; ?>"><?php echo $vehicle['make'] . ' ' . $vehicle['model']; ?></option>
            <?php endforeach; ?>
          </select>
          <br><br>
        </div>

        <!-- Submit input for modifying reservation -->
        <input type="button" value="Modify Reservation" onclick="confirmModification()">
      </form>
    <?php } else {
      echo "No reservations on file";
      }?>
    </main>

    <footer>
    </footer>
  </div>
</body>

</html>
