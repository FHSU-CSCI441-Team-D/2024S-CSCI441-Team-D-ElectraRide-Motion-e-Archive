# ElectraRideMotion

Unit testing

Getting started
a) You will need to download and install XAMPP (this will allow you to open the php files as the webpage)
https://www.apachefriends.org/download.html

b) Once XAMPP is installed you need to download this repository into the XAMPP folder (i.e. C:\xampp\htdocs\...)

c) Open up the XAMPP application and select "Start" for the Apache line, then select "Start" for the "MySQL" line.

d) Open your web browser and in the URL type "127.0.0.1" (this will open up your local host to the XAMPP folder)

e) From the listed files, select the file you saved as this repository.

f) Once you have the homescreen up, refer to "README.md" on testing the various features of ElectraRideMotion.