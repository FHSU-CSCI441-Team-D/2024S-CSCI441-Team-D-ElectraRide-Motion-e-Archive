# ElectraRideMotion

File Descriptions:

code -> ElectraRideMotion

admin.css - provides the css exclusivly for the admin.php
admin.php - provides the HTML & PHP for the admin vehicle managment page.
apache.conf - used by docker to configure the apache server container
charging.php - provides the HTML & PHP for the chargin station page
DOCKER.md - explains how to download and run docker
docker-compose.yml - provides service settings for docker
dockerfile - provides the script to setup and run the docker container
index.php - provides the HTML & PHP for the landing home page
login.php - provides the HTML & PHP for the login form and logout message
modify-reservation.php - HTML, PHP, and javascript for the modify reservation page
reservations.php - provides the HTML & PHP for the reservations page
sign-up.php - provies the HTML & PHP for the sign up page
vehicles.php - provides the HTML & PHP for the Vehicles page

->classes
dbh.class.php - provides the class php & sql to connect to the database
login.class.php - provides the class php and sql to get user
logincontr.class.php - provides the class php and sql to log the user in
signup.class.php - provides the class to check and set user
signupcontr.class.php - provides the class to create a user and verify the data

->css
style.css - main css file used for the entire website minus the admin page

->images
0.JPG - image coming soon visual
1.JPG through 25.JPG - vehicle images used by the vehicle page. image name is referenced by the database
Logo.png - background image for home page

->includes
autoLoader.inc.php - This code implements a custom autoloading mechanism in PHP. When your script attempts to use a class, the myAutoloader function is automatically triggered. It dynamically determines the location of the class file based on the script's location and includes the file if it exists. This eliminates the need to manually include every class file in your script
header.inc.php - this is the code for the navegation included in every page
login.inc.php - grabs the post data when user tries to log in and creates a new login instance.
logout.inc.php - closes the session to log a user out
reservation.inc.php - creates the reservation class, holds the CRUD opperations
signup.inc.php - grabs the post data when a user creates an account and creates the class and calls the signupuser function
vehicle.inc.php - creates the vehicle class and holds the CRUD functions used by both vehicle page and admin page.

->script
date.js - holds the date function and the dropdown function for the navigation header
reservation.js - holds the script for the reservation page
script.js - holds the script for the vehicle page modal


1. Set up a local development environment

XAMPP provides a local apache server, php myadmin, and a mariaDB SQL database by default.
please watch the following YouTube tutorial
https://youtu.be/btauAEqaifw?si=0WQsUwYdR0nJGrud

you can download XAMPP from here:
https://www.apachefriends.org/download.html

we reccomend visual studio code for your source code editor:
https://code.visualstudio.com/download

2. How to set up the database

Step One:
Get started with PostgreSQL in your local development environment
Codecademy provides a great guide to get Postgres set up locally for Windows, Mac, & Linux
https://www.codecademy.com/article/installing-and-using-postgresql-locally
The guide will help you install Postgres and Postbird - a GUI client for Postgres.

Step Two:
- In your XAMPP folder, you are aware of the htdocs folder. There is also a php folder inside the XAMPP folder. 
- Open the php folder, and you should find a php.ini file. Open this file in an editor like VS Code. 
- Be careful! Do not change any setting except the one I am telling you to. 
- Search for pdo_pgsql (I found mine on line 948 but yours may be elsewhere). Use the Find function of your editor.
- Remove the semi-colon from the beginning of the line and save the file. You have just enabled Postgres to work with PDO. 
- Save the file and restart your Apache server in XAMPP.

Step Three:
My recommendations after installing Postbird:
- Play around with Postbird to understand how you can use it to build a database and query the database.
PHP Database Connection Class for PostgreSQL
The Database class is located in ->classes - file: dbh.class.php

Step Four:
Now you are ready to move to an online database.
Deploy a PostgreSQL database on Render.com: 
You will need to get a free account on Render.com.
You can use your GitHub account which makes it as easy as a couple of clicks.
The following page steps you through deploying a PostgreSQL database on Render.com: https://docs.render.com/databases#create-your-database
Afterwards, use the connection information you get from Render and connect to your hosted database with Postbird: https://docs.render.com/databases#connecting-with-the-external-url
When you are logged in on Render.com, go to your Postgres database page. There should be a "Connect" button near the top right of the page. Click "Connect" > "External Connection" > and then copy the "External Database URL". You need this URL for the instructions below.

Step Five:
Connecting with Postbird to the online Postgres database: 
In Postbird, in the Connection tab, go to the "Connect URL" tab. You will be able to paste in the "External Database URL" you copied from Render.com but you should also add:
?ssl=true
at the end of the URL. Without this addition, you will likely receive a connect error. 

Step Six:
Connecting with PHP to the online Postgres database: 
You will need to break these values out for your PDO connection in PHP. Here is a break of the "External Database URL": 
postgres://<username>:<password>@<host>/<dbname>
For example, replace <username> with your username when you reconstruct this URL in your PHP code.
The "External Database URL" already has the values in it.
You do NOT want to send these values from this URL to a GitHub repository. Therefore, you should retrieve each value with getenv() and set each value as environment values for your PHP project when it is deployed.

unfortunatly postbird has not been updated to keep up with the latest version of PostgreSQL so we were unable to download the schema.
screenshots of our database can be found in the code -> database folder

3. How to deploy the docker server
docker deployment instructions on render can be found by watching the below youtube tutorial
https://youtu.be/NL23_cVq6XI


4. How to navagate the program

    I) Sign Up & Log In
        a) If already signed up skip to step "e".
        b) Click the "Sign Up" button.
        c) Enter your "Username", "Password", "Repeat Password", and "E-Mail"
        d) Click "Sign Up".
        e) Click "Log In".
        f) Enter your "Username" and "Password".
        g) Click "Login".
    
    II) Viewing Vehicles
        a) On the homescreen click "Vehicles"
        b) You can view all available vehicles displayed on the screen.
        c) By clicking on a vehicle:
            - View a larger image of the vehicle
            - View vehicle information (i.e. year, make, model, type, range, daily rate)
            - If not currently logged in: promted to log in to reserve the vehicle.
            - If already logged in: given the option to click "Reserve Vehicle" which will take you to the reservations page.
        d) On the right of the screen there is a filter option.
            - To view only a certain make, click the dropdown menu titled "Make:" and select desired vehicle manufacurer.
            - If you desire to go back to viewing all vehicles click the "Reset" button.
    
    III) Charging Stations
        a) on the navigation menu click "Charging Stations" to view the charging stations map
        b) This feature has not yet been added

    IV) Vehicle Reservations
        a) Once logged in, click "Reservations" from the navigation menu.
        b) First select the "Date to pick up vehicle".
        c) Then select the "Date to drop off vehicle".
        b) Based off the selected time range, the drop down menu will be populated with all the available vehicles.
        e) Under "Choose a car:" select the drop down menu and select the desired vehicle.
        f) After selecting a vehicle you recieve a popup confirmation window.
        g) Select "OK" to confirm or "Cancel" to cancel.

    V) Modify Reservations
        a) On the navigation menu select your username, a dropdown menu appears.
        b) On the dropdown menu select "Modify Reservation".
        c) The webpage will display your:
            - Confirmation number
            - Pickup Date
            - Return Date
            - Make & model of reserved vehicle
            - Daily rate
        d) select the dropdown menu titled "Choose modification"
        e) Select either:
            - "modify pickup/dropoff dates"
                - Which will populate a calender to adjust the pickup and dropoff dates
            - "modify vehicle"
                - Which will populate with a dropdown menu of available vehicles within your reservation date range.
            - "Cancel reservation"
                - Which will cancel your reservation.
        f) After making your selection click "Modify Reservation"
        g) You recieve a confirmation popup displaying the modifications made to your reservation.
        h) Click "OK" to confirm these changes or "Cancel" to cancel out of these changes.